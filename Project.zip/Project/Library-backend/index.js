const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');
const port = 8080;

const db = require('./util/database');

// routes
const usersRoutes = require('./routes/users');
const booksRoutes = require('./routes/books');
const bookBorrowRoutes = require('./routes/bookBorrow');

// cors middleware
app.use(cors( ));

// bodyparser middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


app.use('/users', usersRoutes);
app.use('/books', booksRoutes);
app.use('/bookBorrow',bookBorrowRoutes);

// // error handling middleware
// app.use((err, req, res, next) => {
//     res.send({
//         error: true,
//         message: 'Server Error',
//         err: err
//     });
// });

app.listen(port, () => {
    console.log(`App is listening to port ${port}`);
});
