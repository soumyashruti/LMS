const express = require('express');
const router = express.Router();

const auth = require('../middlewares/auth');
const booksController = require('../controllers/books');

//Authentication code
// router.get('/', auth.checkAuth, employeeController.getAllEmployees);

// router.post('/', auth.checkAdmin, employeeController.addEmployee);

// router.put('/:id', auth.checkAdmin, employeeController.checkEmployeeId, employeeController.updateEmployee);

// router.delete('/:id', auth.checkAdmin, employeeController.checkEmployeeId, employeeController.deleteEmployee);

// router.get('/allBooks',auth.checkAuth, booksController.getAllBooks);
// router.get('/oneBook/:bookid',auth.checkAuth, booksController.checkBookId);

// router.post('/addBooks',auth.checkAdmin, booksController.addBooks);

// //router.put('/:book_id',  booksController.checkBookId, booksController.updateBooks);
// router.put('/updateBook/:bookid', auth.checkAdmin, booksController.updateBooks);

// router.delete('/:bookid', auth.checkAdmin, booksController.deleteBooks);

router.get('/allBooks', booksController.getAllBooks);
router.get('/oneBook/:bookid', booksController.checkBookId);

router.post('/addBooks', booksController.addBooks);

//router.put('/:book_id',  booksController.checkBookId, booksController.updateBooks);
router.put('/updateBook/:bookid',  booksController.updateBooks);

router.delete('/:bookid',  booksController.deleteBooks);

module.exports = router;





















// const express = require('express');
// const router = express.Router();

// const auth = require('../middlewares/auth');
// const booksController = require('../controllers/books');

// //Authentication code

// router.get('/', booksController.getAllBooks);

// router.post('/', booksController.addBooks);

// router.put('/:bookid',  booksController.checkBookId, booksController.updateBooks);
// //router.put('/:bookid', booksController.updateBooks);

// router.delete('/:bookid',  booksController.checkBookId, booksController.deleteBooks);
// //router.delete('/:bookid',  booksController.checkBookId, booksController.deleteBooks);

// module.exports = router;











// // const express = require('express');
// // const router = express.Router();

// // const auth = require('../middlewares/auth');
// // const booksController = require('../controllers/book');

// // //Authentication code

// // router.get('/', booksController.getAllBooks);

// // router.post('/', booksController.addBooks);

// // router.put('/:bookid',  booksController.checkBookId, booksController.updateBooks);

// // router.delete('/:bookid',  booksController.checkBookId, booksController.deleteBooks);

// // module.exports = router;
