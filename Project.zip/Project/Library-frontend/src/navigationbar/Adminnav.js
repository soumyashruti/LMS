import React from 'react'
import { Link } from 'react-router-dom'
import {FaHome, FaPencilAlt, FaShopify, FaShower, FaSignOutAlt} from 'react-icons/fa';
import {FcLibrary} from 'react-icons/fc';
import {BiBookAdd,BiBookAlt} from 'react-icons/bi';
import {FiUsers} from 'react-icons/fi';


function out(){
  // localStorage.removeItem()
 window.localStorage.removeItem("token");
 }

const btn ={
    
  paddingLeft: "400px",
 
}

export default function AdminNavbar() {
    return (
        <nav class="navbar navbar-expand-lg navbar-light bg-info">
          <div class="container-fluid">
            <Link class="navbar-brand" href="#"  style={{fontStyle:"italic"}}><FcLibrary/><b>Library Management System</b></Link>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
              <ul class="navbar-nav">
                <li class="nav-item">
                  <Link to="/home" class="nav-link active" aria-current="page" href="#"><FaHome/>Home</Link>
                </li>
                <li class="nav-item">
                  <Link to="/addBooks" class="nav-link active" href="#"><BiBookAdd/>AddBooks</Link>
                </li>
                <li class="nav-item">
                  <Link to="/addUser" class="nav-link active" href="#"><FiUsers/>AddUser</Link>
                </li>
                <li class="nav-item">
                  <Link to="/showBooks" class="nav-link active" href="#"><BiBookAlt/>ShowBooks</Link>
                </li>
                <li class="nav-item">
                  <Link to="/editBooks" class="nav-link active" href="#"><FaPencilAlt/>EditBooks</Link>
                </li>
                <li class="nav-item">
                  <Link to="/home" class="nav-link active" onClick={out} href="#" style={btn}><FaSignOutAlt/>LogOut</Link>
                </li>
              </ul>
            </div>
          </div>
</nav>           
)
}

 
// import React from 'react'
// import { Link } from 'react-router-dom'
// import axios from "axios";


// function out(){
//     // localStorage.removeItem()
//    window.localStorage.removeItem("token");
//    }
//    // onclick=
//  //  window.localStorage.clear(); //clear all localstorage
//    //window.localStorage.removeItem("token"); //remove one item

// const btn ={
    
//     paddingLeft: "1300px",
   
//   }
// export default function AdminNavbar() {
//     return (
//         <nav class="navbar navbar-expand-lg navbar-light bg-info">
//                 <div class="container-fluid">
//                     <Link class="navbar-brand" href="#">My Library</Link>
//                     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
//                     <span class="navbar-toggler-icon"></span>
//                     </button>
//                     <div class="collapse navbar-collapse" id="navbarNav">
//                         <ul class="navbar-nav">
//                             <li class="nav-item">
//                              <Link to="/" class="nav-link active" aria-current="page" href="#">Home</Link>
//                             </li>
//                             <li class="nav-item">
//                                 <Link to="/AddUser" class="nav-link  active" href="#" >Add User</Link>
//                             </li>
//                             <li class="nav-item">
//                                 <Link to="/AddBooks" class="nav-link  active" href="#" >Add Books</Link>
//                             </li>
//                             {/* <li class="nav-item">
//                                 <Link to="/AccountCreation" class="nav-link  active" href="#" >AccountCreation</Link>
//                             </li> */}
//                             <li class="nav-item">
//                                 <Link to="/ShowBooks" class="nav-link  active" href="#" >ShowBooks</Link>
//                             </li>
//                             <li class="nav-item">
//                                 <Link to="/EditBooks" class="nav-link  active" href="#" >EditBooks</Link>
//                             </li>
//                             <li class="nav-item">
//                                 <Link to="/History" class="nav-link  active" href="#" >History</Link>
//                             </li>
//                             <li class="nav-item">
//                                 <Link to="/" text-align="right" class="nav-link  active" href="#" onClick={out} tabindex="-1" style={btn} aria-disabled="true">LogOut</Link>
//                             </li>
//                         </ul>
//                     </div>
//                 </div>
//             </nav> 
           
//     )
// }