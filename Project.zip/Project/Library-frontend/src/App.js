//import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router,Route, Switch } from 'react-router-dom';
//import {FaEnvelope, FaHome, FaPhone, FaUser} from 'react-icons/fa';
//import {FcAbout, FcLibrary} from 'react-icons/fc';

import Home from './Components/home/Home';
import ContactUs from './Components/contactUs/ContactUs';
import AboutUs from './Components/AboutUs/AboutUs';
import Signup from './Components/signup/Signup';
//import ak from './Components/signup/ak';

import AdminLogin from './Components/admin/adminLogin/AdminLogin';
//import accountCreation from './Components/admin/AccountCreation/AccountCreation';
import AddBooks from './Components/admin/addBooks/AddBooks';
import AddUser from './Components/admin/addUser/AddUser';
import ShowBooks from './Components/admin/showBooks/ShowBooks';
import EditBooks from './Components/admin/editBook/EditBooks';

import UserLogin from './Components/user/userLogin/UserLogin';
import BookBorrow from './Components/user/bookBorrow/BookBorrow';
//import BookSearch from './Components/user/bookSearch/BookSearch';
import BookShow from './Components/user/bookShow/BookShow';

function App() {
  return (
    // <div className="App" style={{backgoundImage:"./assets/purple.png"}}>

        <div className="App" style={{ 
             backgroundImage: `url("https://images2.minutemediacdn.com/image/upload/c_fill,g_auto,h_1248,w_2220/f_auto,q_auto,w_1100/v1554741904/shape/mentalfloss/559404-istock-512966920_0.jpg")`,
             height:"100vh"
          }}>
      <Router>
        <Switch>
              <Route exact path="/" component={Home}/>
              <Route path="/home" component={Home}/>
              <Route path="/contactUs" component={ContactUs}/>
              <Route path="/aboutUs" component={AboutUs}/>
              <Route path="/signup" component={Signup}/>
             
              <Route path="/adminLogin" component={AdminLogin}/>
              <Route path="/addBooks" component={AddBooks}/>
              <Route path="/addUser" component={AddUser}/>
              <Route path="/showBooks" component={ShowBooks}/> 
              <Route path="/editBooks" component={EditBooks}/> 

              <Route path="/userLogin" component={UserLogin}/>
              <Route path="/bookBorrow" component={BookBorrow}/>
              <Route path="/bookShow" component={BookShow}/> 
        </Switch>
      </Router>
</div>
);
}
export default App;

