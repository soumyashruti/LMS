import React from 'react';
import HomeNavbar from '../../navigationbar/Homenav';

 function AboutUs() {
     
    return (
        <>
            <div>
                <HomeNavbar/>
            </div>
        <div>
            <h1 class="cont" style={{color:"crimson", textAlign:"center", padding: "10px"}}>About Us</h1>
            <p class="constant" style={{paddingLeft:"15px"}}>A Library management system is a software that uses to maintain the record of the library. It contains work like the number of available books in the library, the number of books are issued or returning or renewing a book or late fine charge record, etc. Library Management Systems is software that helps to maintain a database that is useful to enter new books and record books borrowed by the members, with the respective submission dates. Moreover, it also reduces the manual record burden of the librarian.</p>
                    
          {/* <img src="https://jgu.edu.in/wp-content/uploads/2019/03/global-library-main_0_0-1.jpg" class="card-img-top" style={{width: "1365px",
    height:"400px"}}  alt="..."/> */}
        </div>
        </>
    )
}
export default AboutUs;