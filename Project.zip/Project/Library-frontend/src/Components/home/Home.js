import React from 'react'
import './Home.css'
import {Link} from 'react-router-dom' 
import HomeNavbar from '../../navigationbar/Homenav'

export default function Home() {
    return (
  
        <>
          <div>  
            <HomeNavbar/>
          </div>
          <div>
            <h1 id="home" style={{fontSize:"40px"}}>Welcome to Digital Library Management System</h1>
            {/* <p id="hpara" style={{fontSize:"30px"}}>A Library management system is a software that uses to maintain the record of the library. It contains work like the number of available books in the library, the number of books are issued or returning or renewing a book or late fine charge record, etc. Library Management Systems is software that helps to maintain a database that is useful to enter new books and record books borrowed by the members, with the respective submission dates. Moreover, it also reduces the manual record burden of the librarian.
                </p> */}
          </div>
        
          {/* <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="https://images2.minutemediacdn.com/image/upload/c_fill,g_auto,h_1248,w_2220/f_auto,q_auto,w_1100/v1554741904/shape/mentalfloss/559404-istock-512966920_0.jpg" style={{height:"400px", width:"100px"}} class="d-block w-100" class="d-block w-100" alt="..."></img>
              </div>
              <div class="carousel-item">
                <img src="https://imgstaticcontent.lbb.in/lbbnew/wp-content/uploads/sites/1/2016/04/Delhi-libraries.jpg?fm=webp&w=750&h=500&dpr=1" class="d-block w-100" alt="..."></img>
              </div>
              <div class="carousel-item">
                <img src="https://imgstaticcontent.lbb.in/lbbnew/wp-content/uploads/sites/1/2016/04/Delhi-libraries.jpg?fm=webp&w=750&h=500&dpr=1" class="d-block w-100" alt="..."></img>
              </div>
            </div>
          </div>
          */}
         {/* <div className="card" style={{width: "35rem"}}>
                <img src="https://www.vrsiddhartha.ac.in/wp-content/uploads/2019/09/NANI3506-1024x683.jpg" class="card-img-top" alt="..."/>
                <div class="card-body">
                <p style={{color:"black"}} class="card-text"><b></b><br/>College Library</p>
            </div>
            </div>

            <div className="card" style={{width: "35rem"}}>
                <img src="https://static.theprint.in/wp-content/uploads/2018/07/Medlibrary-e1530626526256-696x350.jpg" class="card-img-top" alt="..."/>
                <div class="card-body">
                <p style={{color:"black"}} class="card-text"><b></b><br/>Public Library</p>
            </div> 
            </div> */}

        
        
       </>
    )
}

