import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import AdminNavbar from '../../../Navbar/AdminNavbar';
import axiosInstance from '../../../Inter/Interceptor';

const btn1 ={ 
    cursor:"pointer",
     width:"100px", 
     margin:"5px 0",
     borderRadius:"50px",
     marginRight:"10px"
    }
const btn2 ={ 
    cursor:"pointer",
     width:"100px", 
     margin:"5px 0",
     borderRadius:"50px"
    }

    export default class BookAccept extends Component {

        constructor(props) {
            super(props);
            this.state = { booksCollection: [] } 
            this.deleteBook = this.deleteBook.bind(this);
        }
    
        deleteBook = (book_id) => {
            if (window.confirm('Sure, you want to delete the record?')) {
                axiosInstance().delete('/book/'+ book_id)
            .then((res) => {
                console.log('Book deleted successfully!!')
                alert('Deleted succesfully')
                this.setState({
                    booksCollection: this.state.booksCollection.filter( remove => remove.book_id !== book_id)
                })
            }).catch((error) => {
                console.log(error)
            })
        }}
        componentDidMount() {
            //console.log("Component Mounted");
            axiosInstance().get('/book/allBooks')
                .then(res => {
                   // console.log("res",res.data);
                    this.setState({ booksCollection: res.data.book_info });
                })
                .catch(function (error) {
                    console.log(error);
                })
        }
        
        render() {
        return (
            <>
            <div ><AdminNavbar/></div>
            <div >
                 <div className="row">
                        <div className="col-10">
                            <div className="row">
                                 <div className="col-2"></div> 
                                <div className="col-10">
                                <h2 className="text-center " style={{color:"green", textAlign:"center", fontSize:"40px"}}>Book Accept</h2>
                                <div >
                                <table class="table table-hover table-bordered table-secondary table-condensed mt-2" >
                                        <thead class="table-hover" style={{backgroundColor:"Crimson", textAlign:"center"}}>
                                        <tr>                                                                                                        
                                         <th scope="col">BOOK ID</th>
                                         <th scope="col">EMAIL</th>
                                         <th scope="col">DATE ADDED</th>
                                         <th scope="col">DUE DATE</th>
                                         <th scope="col">STATUS</th>
                                         <th scope="col">ACTION</th>
 						                </tr>
                                        
                                        </thead>
                                        <tbody style={{backgroundColor:"Lightcyan", textAlign:"center"}}>
                                       
                                            {this.state.booksCollection.map(book => (
                                                <tr>
                                                    <td>
                                                        {book.book_id}  
                                                    </td>
                                                     <td>
                                                        {book.email}
                                                    </td> 
                                                    <td>
                                                        {book.date_added}
                                                    </td>
                                                    <td>
                                                        {book.due_date}
                                                    </td>
                                                    <td>
                                                        {book.status}
                                                    </td>
                                                    <td scope="col-3" >
                                                    <Link to={{pathname:"/EditBooks",query:book.book_id}} state={book.book_id}><button size="sm" style={btn1} className="btn btn-outline-success">Accept</button></Link>
                                                 <button size="sm" onClick={() => this.deleteBook(book.book_id)} style={btn2}className="btn btn-outline-danger ">Reject</button>
                                                 </td>
                                                </tr>
                                            ))}
    
                                        </tbody>     
                                </table>
                                </div>
                                </div>
                                {/* <div className="col-2"></div> */}
                            </div>
                        </div>
                  </div>          
            </div>
            </>
        )
    }
    }   