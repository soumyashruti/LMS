//import Axios from 'axios';
import React, { Component } from 'react';
import AdminNavbar from '../../../navigationbar/Adminnav';
import axiosInstance from '../../../Inter/Interceptor';

const form = {
    border:"lightgrey solid 2px",
    boxShadow: "0px 10px 30px black",
    borderRadius: "10px",
    align:"center",
    backgroundColor:"white"
}

export default class EditBooks extends Component {

    constructor(props) {
      super(props)
      this.onChangeBookId = this.onChangeBookId.bind(this);
      this.onChangeBookTitle = this.onChangeBookTitle.bind(this);
      this.onChangeCategoryId = this.onChangeCategoryId.bind(this);
      this.onChangeAuthor = this.onChangeAuthor.bind(this);
      this.onChangeBookCopies = this.onChangeBookCopies.bind(this);
      this.onChangeBookPub = this.onChangeBookPub.bind(this);
      this.onChangePublisherName = this.onChangePublisherName.bind(this);
      this.onChangeIsbn = this.onChangeIsbn.bind(this);
      this.onChangeCopyrightYear = this.onChangeCopyrightYear.bind(this);
      //this.onChangeDateReceive = this.onChangeDateReceive.bind(this);
      this.onChangeDateAdded = this.onChangeDateAdded.bind(this);
      this.onChangeStatus = this.onChangeStatus.bind(this);

      this.onSubmit = this.onSubmit.bind(this);
      //State
      this.state = {
        bookid: '',booktitle:'',categoryid:'',author: '', bookcopies:'',bookpub:'', publishername:'', isbn:'', copyrightyear:'', dateadded:'', status:''
      } //date_receive:'',
  }

  componentDidMount() {
   // console.log(this.props.match.params.book_id);
    console.log(this.props.location.query);
    
    axiosInstance().get('/books/oneBook/'+ this.props.location.query)
     //axiosInstance.get('/book/allBooks' + this.props.match.params.book_id)
        .then(res => {
          console.log("",res.data);
          this.setState({
            bookid: res.data.book[0].bookid ,
            booktitle: res.data.book[0].booktitle,
            categoryid: res.data.book[0].categoryid,
            author: res.data.book[0].author, 
            bookcopies: res.data.book[0].bookcopies,
            bookpub: res.data.book[0].bookpub, 
            publisher_name: res.data.book[0].publishername,
            isbn: res.data.book[0].isbn, 
            copyrightyear: res.data.book[0].copyrightyear,
            dateadded: this.dateFormat(res.data.book[0].dateadded),  
            //date_receive: res.data.allBooks[0].date_receive, 
            status: res.data.book[0].status
          });
        })
        .catch((error) => {
          console.log(error);
        })
    }
dateFormat(val){
    let dt= new Date(val);
    let yr=dt.getFullYear();
    let mm=dt.getMonth();
    let dd=dt.getDate();
    return yr+'/'+mm+'/'+dd;
}
onChangeBookId(e) {
    this.setState({ bookid: e.target.value })
}
onChangeBookTitle(e) {
    this.setState({ booktitle: e.target.value })
}
onChangeCategoryId(e) {
    this.setState({ categoryid: e.target.value })
}
onChangeAuthor(e) {
    this.setState({ author: e.target.value })
}

onChangeBookCopies(e) {
    this.setState({ bookcopies: e.target.value})
} 
onChangeBookPub(e) {
    this.setState({ bookpub: e.target.value})
} 
onChangePublisherName(e) {
    this.setState({ publishername: e.target.value})
} 
onChangeIsbn(e){
    this.setState({ isbn: e.target.value})
}
onChangeCopyrightYear(e) {
    this.setState({ copyrightyear: e.target.value})
} 
onChangeDateAdded(e) {
    this.setState({ dateadded: e.target.value})
} 
onChangeStatus(e) {
    this.setState({ status: e.target.value})
} 


onSubmit(e) {
    e.preventDefault()

    const userObject = {
      bookid: this.state.bookid ,
      booktitle: this.state.booktitle,
      categoryid: this.state.categoryid,
      author: this.state.author, 
      bookcopies: this.state.bookcopies,
      bookpub: this.state.bookpub, 
      publishername: this.state.publishername,
      isbn: this.state.isbn, 
      copyrightyear: this.state.copyrightyear, 
      dateadded: this.state.dateadded, 
      status: this.state.status
    };
    //   role:"user"
// console.log(userObject);

axiosInstance().put('/books/updateBook/' + this.props.location.query, userObject)
        .then((res) => {
           
            alert('Books details updated successfully')
           // console.log('Books successfully updated')
          }).catch((error) => {
            console.log(error)
          })

          /////////////////////////////////
        this.props.history.push('/ShowBooks')
        // componentDidMount() {
            // axiosInstance().get('/book/oneBook/'+ this.props.match.params.book_id, userObject)
            //   .then(res => {
            //       // console.log(res.data);
            //       this.setState({ userObject: res.data.allBooks });
            //   })
            //   .catch(function (error) {
            //       console.log(error);
            //   })

    //this.setState({ book_id: '',book_title:'',category_id:'',author: '', book_copies:'',book_pub:'', publisher_name:'', isbn:'', copyright_year:'', date_added:'', status:''})
} //date_receive:''


render()
{
    return (
        <>
         <div><AdminNavbar/></div>
        <div>
            <div className="row">
                    <div className="col-10">
                        <div className="row">
                            <div className="col-2"></div>
                            <div className="col-10">
                                <div className="jumbotron  mt-5" style={form}>
                                    <div>
                                    <h3 style={{textAlign:"center", marginBottom:"30px", color:"crimson"}}>Edit your book details here....</h3>
                            <form onSubmit={this.onSubmit}>
                                <div className="form-row">
                                        <div className="col">
                                        <label htmlFor="bookId">Book Id<span className="required text-danger">*</span></label>
                                        <input type="number" required name="bookid" id="bookId" disabled value={this.state.bookid} onChange={this.onChangeBookId}   className="form-control" style={{backgroundColor:"white"}}/>
                                        </div>

                                        <div className="col">
                                        <label htmlFor="categoryId">Category Id<span className="required text-danger">*</span></label>
                                        <input type="number" required name="categoryid" id="categoryId"  value={this.state.categoryid} onChange={this.onChangeCategoryId} className="form-control" />
                                        </div>
                                        <br></br>
                                        <div className="col">
                                        <label htmlFor="bookTitle">Book Title<span className="required text-danger">*</span></label>
                                        <input type="text" required name="booktitle" id="bookTitle" value={this.state.booktitle} onChange={this.onChangeBookTitle}   className="form-control" />
                                        </div>
                                       

                                        <div className="col">
                                        <label htmlFor="author">Author<span className="required text-danger">*</span></label>
                                        <input type="text" required name="author" id="author" value={this.state.author} onChange={this.onChangeAuthor}   className="form-control" />
                                        </div>
                                    </div>
                                    
                                    <div className="form-row">
                                        <div className="col">
                                        <label htmlFor="bookCopies">Book Copies<span className="required text-danger">*</span></label>
                                        <input type="number" required name="bookcopies" id="bookCopies" value={this.state.bookcopies} onChange={this.onChangeBookCopies}   className="form-control" />
                                        </div>

                                        <div className="col">
                                        <label htmlFor="bookPub">Book Pub<span className="required text-danger">*</span></label>
                                        <input type="text" required name="bookpub" id="bookPub" value={this.state.bookpub} onChange={this.onChangeBookPub}   className="form-control" />
                                        </div>

                                        <div className="col">
                                        <label htmlFor="publisherName">Publisher Name<span className="required text-danger">*</span></label>
                                        <input type="text" required name="publishername" id="publisherName" value={this.state.publishername} onChange={this.onChangePublisherName}   className="form-control" />
                                        </div>

                                        <div className="col">
                                        <label htmlFor="isbn">Isbn<span className="required text-danger">*</span></label>
                                        <input type="text" required name="isbn" id="isbn" value={this.state.isbn} onChange={this.onChangeIsbn}   className="form-control" />
                                        </div>
                                        </div>

                                        <div className="form-row">
                                        <div className="col">
                                        <label htmlFor="copyrightYear">Copyright Year<span className="required text-danger">*</span></label>
                                        <input type="number" required name="copyrightyear" id="copyrightYear" value={this.state.copyrightyear} onChange={this.onChangeCopyrightYear}   className="form-control" />
                                        </div>

                                        
                                        <div className="col">
                                        <label htmlFor="dateAdded">Date Added<span className="required text-danger">*</span></label>
                                        <input type="date"  name="dateadded" id="dateAdded" value={this.state.dateadded} onChange={this.onChangeDateAdded}   className="form-control" />
                                        </div>

                                        <div className="col">
                                        <label htmlFor="status">Status<span className="required text-danger">*</span></label>
                                        <input type="text" required name="status" id="status" value={this.state.status} onChange={this.onChangeStatus}   className="form-control" />
                                        </div>
                                
                                    </div>
                                        <div className=" text-left " style={{marginTop:"5px"}}>
                                            <button type="submit"   className="btn btn-info m-2 p-2" style={{width:"100px"}}>EditBook</button>
                                                    {/* <button type="reset" className="btn btn-outline-info m-2 p-2"> Reset</button> */}
                                        </div>
                            </form>
                                    </div>
                                </div>
                            </div>
                            <div className="col-2"></div>
                        </div>
                    </div>
            </div>        
        </div>
        </>
    )
}

}