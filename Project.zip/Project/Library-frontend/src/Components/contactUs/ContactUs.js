import React, {Component} from 'react';
//import "./ContactUs.css";
import {Link} from 'react-router-dom';
import { FormErrors } from '../Welcome/FormErrors';
//import {BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import HomeNavbar from '../../navigationbar/Homenav';

const form = {
    border:"lightgrey solid 2px",
    padding: "40px",
    marginTop: "30px",
    marginLeft: "380px",
    marginRight: "485px",
    color: "firebrick",
    fontWeight: "600",
    borderRadius: "10px",
    boxShadow: "0px 10px 30px black",
    backgroundColor:"white"
  }
  
  const btn ={
    marginTop: "10px",
    marginLeft: "5px" ,
    paddingLeft: "40px",
    paddingRight: "40px",
    marginBottom: "10px",
    fontSize: "23px"
  }
  
  const welcome ={
    paddingLeft: "90px",
    marginLeft: "1px",
    marginBottom: "10px",
    color: "crimson",
    fontSize: "30px"
  }

  const image = {
    height:"100px", 
    width:"100%"
    
 }
  
  
  export default class ContactUs extends Component{
  
  constructor (props) {
    super(props);
    this.state = {
      name: '',
      email: '',
      textarea: '',
      formErrors: {name: '', email: '',textarea: '',},
      nameValid:false,
      emailValid: false,
      textareaValid: false,
      formValid: false
      
    }
  }
  
  handleSubmit = e => {
    // alert("done")
    e.preventDefault();
    
  };
  
  handleUserInput = (e) => {
    e.preventDefault();
    const name = e.target.name;
    const value = e.target.value;
    
    this.setState({[name]: value},
                  () => { this.validateField(name, value) });
                  
  }
  
  validateField(fieldName, value) {
    let fieldValidationErrors = this.state.formErrors;
    let nameValid = this.state.nameValid;
    let emailValid = this.state.emailValid;
    let textareaValid = this.state.textareaValid;
    
    
  
    switch(fieldName) {
        case 'name':
        nameValid = value.match(/^([a-zA-Z ]){2,30}$/);
        fieldValidationErrors.name = nameValid ? '': '  is invalid , Name must be in alphabets only ';
        break;
        case 'email':
            emailValid = value.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i);
            fieldValidationErrors.email = emailValid ? '' : ' is invalid , (hint : abc@gmail.com)';
            break;
        case 'textarea':
            textareaValid = value.match(/^([a-zA-Z ]){2,30}$/);
            fieldValidationErrors.textarea = textareaValid ? '': '  is invalid , it should contains maximum 100 words ';
            break;
        
        default:
            break;
    }
    this.setState({formErrors: fieldValidationErrors,
                    nameValid: nameValid,
                    emailValid: emailValid,
                    textareaValid: textareaValid
                  }, this.validateForm);
  }
  
  
  
  validateForm() {
    this.setState({formValid: this.state.nameValid && this.state.emailValid  && this.state.textareaValid});
    
  }
  
  
  errorClass(error) {
    return(error.length === 0 ? '' : 'has-error');
    
  }
  
   render() {

    return (
        <>
            <div>
                <HomeNavbar />
            </div>
            <form style={form} id="lform" className="loginForm" name="validform" onSubmit={this.handleSubmit} noValidate >
          
            <img src="http://www.sgischool.in/Images/ContactUs.png" class="card-img-top" alt="..." style={ image }></img>
            
                <hr style={{borderTop: "2px solid white" , width:"100%" }} />
    
            <div className="panel panel-default">
                <FormErrors formErrors={this.state.formErrors} />
            </div>
    
            <div  class="form-row">
                <div class="col">
                    <div className={`form-group ${this.errorClass(this.state.formErrors.name)}`}>
                        <input type="text" required className="form-control" name="name" placeholder="enter name" value={this.state.name} onChange={this.handleUserInput}  />
                    </div>
                </div>
            </div>

            <div  class="form-row">
                <div class="col">
                    <div className={`form-group ${this.errorClass(this.state.formErrors.email)}`}>
                        <input type="email" required className="form-control" name="email" placeholder="enter email" value={this.state.email} onChange={this.handleUserInput}  />
                    </div>
                </div>
            </div>

            <div  class="form-row">
                <div class="col">
                    <div className={`form-group ${this.errorClass(this.state.formErrors.textarea)}`}>
                        <input type="textarea" style={{height:"100px"}} required className="form-control" name="textarea" placeholder="enter your text" value={this.state.textarea} onChange={this.handleUserInput}  />
                        {/* <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="type your message here..."></textarea> */}
                    </div>
                
                </div>
            </div>
            <div>
            <Link to="/home">
                <button style={btn}  type="submit" className="btn btn-info login" disabled={!this.state.formValid} >Submit</button>
                </Link>
            </div>
            </form> 
 </>
  )
  }
  }















// const image = {
//     height:"150px", 
//     width:"100%"
// }

// const btn = {
//   color: "white",
//   backgroundColor:"darkcyan",
//   marginLeft: "10px",
//   marginBottom: "3px",
// }

// const card = {
// height: "200px"
// }

// const field ={
//     paddingLeft:"4px",
//     paddingRight:"4px",
//     paddingTop:"2px",
//     marginTop:"1px",
//     fontSize:"15px"
// }

// const bg ={
//     backgroundColor:"white"
// }

// const text ={
//     marginLeft:"200px"
// }

//  function ContactUs() {
//     return (
//         <>
//             <div>
//                 <HomeNavbar/>
//             </div>
//         <div>
//                 <div class="card" style={{width: "30rem", marginLeft:"450px", marginTop:"15px"}}>
//                 <img src="http://www.sgischool.in/Images/ContactUs.png" class="card-img-top" alt="..." style={ image }></img>
//                 {/* <div class="card-body" style={{backgroundColor:"white"}}>
//                     <p class="card-text" style={p}>Type your query here...</p>
//                 </div> */}
//                 <div style={bg}>
//                 <div class="mb-3" style={field} >
//                 <label for="exampleFormControlInput1" class="form-label" style={{marginLeft:"200px"}}>Full Name</label>
//                 <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="enter full name"/>
//                 </div>
//                 <div class="mb-3" style={field}>
//                 <label for="exampleFormControlInput1" class="form-label" style={{marginLeft:"190px"}}>Email address</label>
//                 <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="enter mail"/>
//                 </div>
//                 <div class="mb-3" style={field}>
//                 <label for="exampleFormControlTextarea1" class="form-label" style={{marginLeft:"180px"}}>Example text area</label>
//                 <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="type your message here..."></textarea>
//                 </div>

//                 <div>
//                     <Link to="/home"> 
//                     <button type="submit" class="btn" style={btn}>Send Message</button>
//                     </Link>
//                 </div>
//                 </div>
//                 </div>
//         </div>
//     </>
//     )
// }
// export default ContactUs;




       

        
      
