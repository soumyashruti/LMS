import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import HomeNavbar from '../../../navigationbar/Homenav';
import { FormErrors } from '../../Welcome/FormErrors';
import axiosInstance from '../../../Inter/Interceptor';
import jwtDecode from "jwt-decode";
//import './UserLogin.css';

const form = {
  border:"lightgrey solid 2px",
  padding: "40px",
  marginTop: "30px",
  marginLeft: "380px",
  marginRight: "485px",
  color: "firebrick",
  fontWeight: "600",
  borderRadius: "10px",
  boxShadow: "0px 10px 30px black",
  backgroundColor:"white"
}

const btn ={
  marginTop: "15px",
  marginLeft: "5px" ,
  paddingLeft: "40px",
  paddingRight: "40px",
  marginBottom: "10px",
  fontSize: "23px"
}

const welcome ={
  paddingLeft:"130px",
  marginLeft: "1px",
  marginBottom: "10px",
  color: "crimson",
  fontSize: "30px"
}

export default class UserLogin extends Component{

constructor (props) {
  super(props);
  this.state = {
    email: '',
    password: '',
    formErrors: {email: '', password: ''},
    emailValid: false,
    passwordValid: false,
    formValid: false
  }
}

login() {
  //console.log("ok");
  axiosInstance().post('/users/login',{
    email: this.state.email,
    password:this.state.password
  })
      .then(res => {
        //console.log("success");
          if(res.data.token){
            console.log(res.data.token);
            localStorage.setItem("token",res.data.token);
            //--- Admin Check
            var decoded = jwtDecode(res.data.token);
            console.log(decoded);
            //alert(decoded);
            
            if(decoded.role!='User'){
             // alert("ADMIN");
            this.props.history.push('/adminLogin');
             }
             else{
             this.props.history.push('/bookBorrow');
             }

           //this.props.history.push('/BookBorrow');
          }
          else{
            alert("Unable to Login, Please try again.");
          }
      })
      .catch(function (error) {
        //console.log("failed");
        alert(" Failed ,Invalid Login, Please try again.");
          console.log(error);
      })
}

handleSubmit = e => {
  e.preventDefault();
  this.login()
};

handleUserInput = (e) => {
  e.preventDefault();
  const name = e.target.name;
  const value = e.target.value;
  this.setState({[name]: value},
                () => { this.validateField(name, value) });
}

validateField(fieldName, value) {
  let fieldValidationErrors = this.state.formErrors;
  let emailValid = this.state.emailValid;
  let passwordValid = this.state.passwordValid;

  switch(fieldName) {
    case 'email':
      emailValid = value.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i);
      fieldValidationErrors.email = emailValid ? '' : ' is Invalid , (hint : abc@gmail.com) ';
      break;
    case 'password':
      passwordValid = value.match("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{6,})");
      fieldValidationErrors.password = passwordValid ? '': ' is weak , *it should contain atleast one special charcter , one uppercase and numbers*';
      break;
    default:
      break;
  }
  this.setState({formErrors: fieldValidationErrors,
                  emailValid: emailValid,
                  passwordValid: passwordValid
                }, this.validateForm);
}

validateForm() {
  this.setState({formValid: this.state.emailValid && this.state.passwordValid});
}

errorClass(error) {
  return(error.length === 0 ? '' : 'has-error');
}

 render() {
  return (
    <div>
        <HomeNavbar />
        <form style={form} id="lform" name="validform" className="loginForm" onSubmit={this.handleSubmit} noValidate >
            <h2 style={welcome}> User Login </h2>
            <hr style={{borderTop: "2px solid white" , width:"100%" }} />

        <div className="panel panel-default">
            <FormErrors formErrors={this.state.formErrors} />
          </div>
          <div className={`form-group ${this.errorClass(this.state.formErrors.email)}`}>
            <input type="email" required className="form-control" name="email"
              placeholder="enter email"
              value={this.state.email}
              onChange={this.handleUserInput}  />
          </div>
          <div className={`form-group ${this.errorClass(this.state.formErrors.password)}`}>
            <input type="password" className="form-control" name="password"
              placeholder="enter password"
              value={this.state.password}
              onChange={this.handleUserInput}  />
          </div>
        {/* <Link to="/bookBorrow"> */}
          <button style={btn} type="submit" className="btn btn-info login" disabled={!this.state.formValid} >Login</button>
        {/* </Link>   */}
      </form> 
    </div>
)
}
}



















// import React, { Component } from 'react'
// import {Link} from 'react-router-dom';
// import HomeNavbar from '../../../Navbar/HomeNavbar';
// import { FormErrors } from '../../Welcome/FormErrors';
// import axiosInstance from '../../../Inter/Interceptor';
// import jwtDecode from "jwt-decode";


// const form = {
//   // border:"darkseagreen solid 2px",
//   // padding: "40px",
//   // marginTop: "30px",
//   // marginLeft: "380px",
//   // marginRight: "485px",
//   // color: "firebrick",
//   // fontWeight: "600"
//   border:"darkseagreen solid 2px",
//   padding: "40px",
//   marginTop: "30px",
//   marginLeft: "380px",
//   marginRight: "485px",
//   color: "firebrick",
//   fontWeight: "600"
// }

// const btn ={
//   // marginTop: "10px",
//   // marginLeft: "5px" ,
//   // paddingLeft: "40px",
//   // paddingRight: "50px",
//   // marginBottom: "5px",
//   // fontSize: "23px",
//   marginTop: "15px",
//   // marginLeft: "5px" ,
//   paddingLeft: "40px",
//   paddingRight: "110px",
//   marginBottom: "5px",
//   fontSize: "23px",
//    //marginRight:"5px"
 
// }

// const welcome ={
  
//   marginLeft: "1px",
//   marginBottom: "10px",
//   color: "black",
//   textShadow:" 2px 2px red",
//   fontSize: "40px"
// }


// export default class UserLogin extends Component{

// constructor (props) {
//   super(props);
//   this.state = {
//     email: '',
//     password: '',
//     formErrors: {email: '', password: ''},
//     emailValid: false,
//     passwordValid: false,
//     formValid: false
//   }
// }

// login() {
//   //console.log("ok");
//   axiosInstance().post('/users/login',{
//     email: this.state.email,
//     password:this.state.password
//   })
//       .then(res => {
//         //console.log("success");
//           if(res.data.token){
//             localStorage.setItem("token",res.data.token);
//            // window.location.href='http://localhost:3000/BookBorrow';
//             //--- Admin Check
//             var decoded = jwtDecode(res.data.token);
//             console.log(decoded);
//             //alert(decoded);
            
//             if(decoded.role!='User'){
//              // alert("ADMIN");
//             this.props.history.push('/AdminLogin');
//              }
//              else{
//              this.props.history.push('/BookBorrow');
//              }


//            //this.props.history.push('/BookBorrow');
//           }
//           else{
//             alert("Unable to Login, Please try again.");
//           }
//       })
//       .catch(function (error) {
//         //console.log("failed");
//         alert(" Failed ,Invalid Login, Please try again.");
//           console.log(error);
//       })
// }



// handleSubmit = e => {
//   e.preventDefault();
//   //console.log(this.state.email)
//   this.login()
  
// };

// handleUserInput = (e) => {
//   e.preventDefault();
//   const name = e.target.name;
//   const value = e.target.value;
//   this.setState({[name]: value},
//                 () => { this.validateField(name, value) });
// }

// validateField(fieldName, value) {
//   let fieldValidationErrors = this.state.formErrors;
//   let emailValid = this.state.emailValid;
//   let passwordValid = this.state.passwordValid;

//   switch(fieldName) {
//     case 'email':
//       emailValid = value.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i);
//       fieldValidationErrors.email = emailValid ? '' : ' is invalid , (hint : xyz@gmail.com) ';
//       break;
//     case 'password':
//       passwordValid = value.match("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{6,})");
//       fieldValidationErrors.password = passwordValid ? '': '  is not strong , *it contain atleast one special charcter , one uppercase and numbers*';
//       break;
//     default:
//       break;
//   }
//   this.setState({formErrors: fieldValidationErrors,
//                   emailValid: emailValid,
//                   passwordValid: passwordValid
//                 }, this.validateForm);
// }

// validateForm() {
//   this.setState({formValid: this.state.emailValid && this.state.passwordValid});
// }

// errorClass(error) {
//   return(error.length === 0 ? '' : 'has-error');
// }

//  render() {
//   return (
//     <div>
//         <HomeNavbar />
//         <form method="post" style={form} id="lform" name="validform" className="loginForm" onSubmit={this.handleSubmit} noValidate >
//             <h2 style={welcome}> Login Here...... </h2>
//             <hr style={{borderTop: "2px solid lightgrey" , width:"100%" }} />

//         <div className="panel panel-default">
//             <FormErrors formErrors={this.state.formErrors} />
//           </div>
//           <div className={`form-group ${this.errorClass(this.state.formErrors.email)}`}>
//             <input type="email" required className="form-control" name="email"
//               placeholder="Email"
//               value={this.state.email}
//               onChange={this.handleUserInput}  />
//           </div>
//           <div className={`form-group ${this.errorClass(this.state.formErrors.password)}`}>
//             <input type="password" className="form-control" name="password"
//               placeholder="Password"
//               value={this.state.password}
//               onChange={this.handleUserInput}  />
//           </div>
//           {/* <Link to="/BookBorrow">  </Link>  */}
//           <button style={btn} type="submit" className="btn btn-info login" disabled={!this.state.formValid} >Login</button>
         
//       </form> 


//     </div>
// )
// }
// }


















































